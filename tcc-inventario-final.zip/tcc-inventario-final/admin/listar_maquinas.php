<?php
include __DIR__ . '/../includes/connect.php';
include __DIR__ . '/../includes/security.php';
$msg = "";
require_admin($conexao);
$msg = (string) ($_GET['msg'] ?? '');

//  CONFIGURAÇÃO DA PAGINAÇÃO 
// quantidade máxima de linhas exibidas por página
$por_pagina = 10;

// verifica se a URL veio com o parâmetro "pagina" (ex: listar_usuarios.php?pagina=2)
if (isset($_GET['pagina']) and is_numeric($_GET['pagina'])) {
    $pagina_atual = (int) $_GET['pagina'];
} else {
    $pagina_atual = 1; // se não veio nada na URL, começa na página 1
}

// garante que a página não seja menor que 1 (evita erro com números negativos ou zero)
if ($pagina_atual < 1) {
    $pagina_atual = 1;
}

// conta quantos usuários existem no total, para saber quantas páginas serão necessárias
$sql_total = "SELECT COUNT(*) AS total FROM equipamento";
$resultado_total = mysqli_query($conexao, $sql_total);
$linha_total = mysqli_fetch_assoc($resultado_total);
$total_registros = $linha_total['total'];

// calcula quantas páginas existem no total (arredondando para cima)
if ($total_registros > 0) {
    //a função ceil() arredonda para cima, garantindo que mesmo que haja um número "sobrando" de registros, uma nova página seja criada para eles
    $total_paginas = ceil($total_registros / $por_pagina);
} else {
    $total_paginas = 1;
}

// se o usuário tentar acessar uma página maior do que existe, ajusta para a última página válida
if ($pagina_atual > $total_paginas) {
    $pagina_atual = $total_paginas;
}

// calcula a partir de qual registro a busca deve começar (o "offset" do SQL)
$inicio = ($pagina_atual - 1) * $por_pagina;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <?php include __DIR__ . '/../includes/head.php'; // Inclui o head de navegação 
    ?>
</head>

<body>
    <?php include __DIR__ . '/../includes/menu.php'; // Inclui o menu de navegação 
    ?>

    <div class="fundo-tabela">
        <div class="card-tabela">
            <?php if ($msg !== '') { ?><p class="info-resultado"><?php echo e($msg); ?></p><?php } ?>
            <div class="fundo-opções">
                <a href="cadastro_maquina.php">CADASTRAR EQUIPAMENTO</a>
                <a href="escanear_nmap.php">ESCANEAR REDE</a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Hostname</th>
                        <th>IPv4</th>
                        <th>MAC</th>
                        <th>Patrimônio</th>
                        <th>Local</th>
                        <th>Sistema Operacional</th>
                        <th>Marca</th>
                        <th>Equipamento</th>
                        <th>Atividade</th>
                        <th>Data de registro</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include __DIR__ . '/../includes/connect.php';
                    $sql = "SELECT * FROM equipamento ORDER BY id DESC LIMIT $inicio, $por_pagina";
                    $resultado = mysqli_query($conexao, $sql);

                    while ($dados = mysqli_fetch_assoc($resultado)) {

                        echo "<tr>";
                        echo "<td>" . e($dados['hostname']) . "</td>";
                        echo "<td>" . e($dados['ipv4']) . "</td>";
                        echo "<td>" . e($dados['mac']) . "</td>";
                        echo "<td>" . e($dados['patrimonio']) . "</td>";
                        echo "<td>" . e($dados['local']) . "</td>";
                        echo "<td>" . e($dados['sistema_operacional']) . "</td>";
                        echo "<td>" . e($dados['marca']) . "</td>";
                        echo "<td>" . e($dados['tipo_equipamento']) . "</td>";
                        echo "<td>" . e($dados['atividade']) . "</td>";
                        echo "<td>" . e($dados['data_registro']) . "</td>";
                        echo "<td>
                        <div class='opcoes'>
                            <a href='feditar_maquina.php?id={$dados['id']}' title='Editar'><img src='" . BASE_URL . "/assets/img/editar.png' width='18'></a>
                            <a href='cadastro_manutencao.php?id=" . (int)$dados['id'] . "' title='Registrar manutenção'><img src='" . BASE_URL . "/assets/img/manutenção.png' width='18' alt='Registrar manutenção'></a>
                            <form class='form-inline' method='post' action='deletar_maquina.php' onsubmit='return confirm(\"Deseja excluir este equipamento?\")'>
                                <input type='hidden' name='csrf_token' value='" . e(csrf_token()) . "'>
                                <input type='hidden' name='id' value='" . (int)$dados['id'] . "'>
                                <button class='btn-icone' type='submit' title='Excluir'><img src='" . BASE_URL . "/assets/img/deletar.png' width='18' alt='Excluir'></button>
                            </form>
                        </div>
                      </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
            <!-- NAVEGAÇÃO DA PAGINAÇÃO -->
            <div class="paginacao">
                <?php
                // botão "Anterior": só fica clicável se não estivermos na primeira página
                if ($pagina_atual > 1) {
                    $pagina_anterior = $pagina_atual - 1;
                    echo "<a href='listar_maquinas.php?pagina=$pagina_anterior'>&laquo; Anterior</a>";
                } else {
                    // se estivermos na primeira página, o botão "Anterior" fica desabilitado (sem link)
                    echo "<a class='desabilitado'>&laquo; Anterior</a>";
                }

                // gera um botão para cada página existente
                for ($i = 1; $i <= $total_paginas; $i++) {
                    if ($i == $pagina_atual) {
                        // página atual recebe a classe "ativo" (já destacada no CSS)
                        echo "<a href='listar_maquinas.php?pagina=$i' class='ativo'>$i</a>";
                    } else {
                        // páginas diferentes da atual ficam com link normal
                        echo "<a href='listar_maquinas.php?pagina=$i'>$i</a>";
                    }
                }

                // botão "Próxima": só fica clicável se não estivermos na última página
                if ($pagina_atual < $total_paginas) {
                    $proxima_pagina = $pagina_atual + 1;
                    // se ainda houver páginas seguintes, o botão "Próxima" recebe um link para a próxima página
                    echo "<a href='listar_maquinas.php?pagina=$proxima_pagina'>Próxima &raquo;</a>";
                } else {
                    // se estivermos na última página, o botão "Próxima" fica desabilitado (sem link)
                    echo "<a class='desabilitado'>Próxima &raquo;</a>";
                }
                ?>
            </div>
        </div>
    </div>
</body>

</html>
